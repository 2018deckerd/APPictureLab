import java.awt.*;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.text.*;
import java.util.*;
import java.util.List; // resolves problem with java.awt.List and java.util.List

/**
 * A class that represents a picture.  This class inherits from 
 * SimplePicture and allows the student to add functionality to
 * the Picture class.  
 * 
 * @author Barbara Ericson ericson@cc.gatech.edu
 */
public class Picture extends SimplePicture 
{
  ///////////////////// constructors //////////////////////////////////
  
  /**
   * Constructor that takes no arguments 
   */
  public Picture ()
  {
    /* not needed but use it to show students the implicit call to super()
     * child constructors always call a parent constructor 
     */
    super();  
  }
  
  /**
   * Constructor that takes a file name and creates the picture 
   * @param fileName the name of the file to create the picture from
   */
  public Picture(String fileName)
  {
    // let the parent class handle this fileName
    super(fileName);
  }
  
  /**
   * Constructor that takes the width and height
   * @param height the height of the desired picture
   * @param width the width of the desired picture
   */
  public Picture(int height, int width)
  {
    // let the parent class handle this width and height
    super(width,height);
  }
  
  /**
   * Constructor that takes a picture and creates a 
   * copy of that picture
   * @param copyPicture the picture to copy
   */
  public Picture(Picture copyPicture)
  {
    // let the parent class do the copy
    super(copyPicture);
  }
  
  /**
   * Constructor that takes a buffered image
   * @param image the buffered image to use
   */
  public Picture(BufferedImage image)
  {
    super(image);
  }
  
  ////////////////////// methods ///////////////////////////////////////
  
  /**
   * Method to return a string with information about this picture.
   * @return a string with information about the picture such as fileName,
   * height and width.
   */
  public String toString()
  {
    String output = "Picture, filename " + getFileName() + 
      " height " + getHeight() 
      + " width " + getWidth();
    return output;
    
  }
  
  /** Method to set the blue to 0 */
  public void zeroBlue()
  {
    Pixel[][] pixels = this.getPixels2D();
    for (Pixel[] rowArray : pixels)
    {
      for (Pixel pixelObj : rowArray)
      {
        pixelObj.setBlue(0);
      }
    }
  }
    
    /** Method to keep only the values of blue*/
    public void keepOnlyBlue() {
    	Pixel[][] pixels = this.getPixels2D();
    	for (Pixel[] rowArray : pixels) {
    		for (Pixel pixelObj: rowArray) {
    			pixelObj.setGreen(0);
    			pixelObj.setRed(0);
    		}
    	}
    }

    /** Method that negates all the pixels in a picture.*/
    public void negate() {
    	Pixel[][] pixels = this.getPixels2D();
    	for (Pixel[] rowArray : pixels) {
    		for (Pixel pixelObj : rowArray) {
    			pixelObj.setRed(255 - pixelObj.getRed());
    			pixelObj.setBlue(255 - pixelObj.getBlue());
    			pixelObj.setGreen(255 - pixelObj.getGreen());
    		}
    	}
    }
  
    /** Method to turn the picture into shades of gray. */ 
    public void grayscale() {
    	Pixel[][] pixels = this.getPixels2D();
    	for (Pixel[] rowArray : pixels) {
    		for (Pixel pixelObj : rowArray) {
    			int avg = (pixelObj.getRed() + pixelObj.getBlue() + pixelObj.getGreen()) / 3;
    			pixelObj.setRed(avg);
    			pixelObj.setBlue(avg);
    			pixelObj.setGreen(avg);
    		}
    	}
    }
    
    /** Method to make the fish easier to see */
    public void fixUnderwater() {
    	Pixel[][] pixels = this.getPixels2D();
    	for (Pixel[] rowArray : pixels) {
    		for (Pixel pixelObj : rowArray) {
    			pixelObj.setBlue(255 - pixelObj.getBlue());
    			pixelObj.setGreen(pixelObj.getBlue());
    		}
    	}
    }
    
    
  /** Method that mirrors the picture around a 
    * vertical mirror in the center of the picture
    * from left to right */
  public void mirrorVertical()
  {
    Pixel[][] pixels = this.getPixels2D();
    Pixel leftPixel = null;
    Pixel rightPixel = null;
    int width = pixels[0].length;
    for (int row = 0; row < pixels.length; row++)
    {
      for (int col = 0; col < width / 2; col++)
      {
        leftPixel = pixels[row][col];
        rightPixel = pixels[row][width - 1 - col];
        rightPixel.setColor(leftPixel.getColor());
      }
    } 
  }
  
  /** Method that mirrors the picture around a vertical 
   * mirror in the center of the picture from right to left */
  public void mirrorVerticalRightToLeft() {
	  Pixel[][] pixels = this.getPixels2D();
	    Pixel leftPixel = null;
	    Pixel rightPixel = null;
	    int width = pixels[0].length;
	    for (int row = 0; row < pixels.length; row++)
	    {
	      for (int col = 0; col < width / 2; col++)
	      {
	        leftPixel = pixels[row][col];
	        rightPixel = pixels[row][width - 1 - col];
	        leftPixel.setColor(rightPixel.getColor());
	      }
	    } 
  }
  
  /** Method that mirrors a picture around a mirror 
   * placed horizontally at the middle of the height of the picture. */
  public void mirrorHorizontal() {
	  Pixel[][] pixels = this.getPixels2D();
	    Pixel topPixel = null;
	    Pixel bottomPixel = null;
	    int width = pixels[0].length;
	    for (int row = 0; row < pixels.length / 2; row++)
	    {
	      for (int col = 0; col < width; col++)
	      {
	    	  topPixel = pixels[row][col];
	    	  bottomPixel = pixels[pixels.length - 1 - row][col];
	    	  bottomPixel.setColor(topPixel.getColor());
	      }
	    }
  }
  
  /** Method that mirrors the picture around a mirror placed horizontally
   * from bottom to top. */
  public void mirrorHorizontalBotToTop() {
	  Pixel[][] pixels = this.getPixels2D();
	    Pixel topPixel = null;
	    Pixel bottomPixel = null;
	    int width = pixels[0].length;
	    for (int row = 0; row < pixels.length / 2; row++)
	    {
	      for (int col = 0; col < width; col++)
	      {
	    	  topPixel = pixels[row][col];
	    	  bottomPixel = pixels[pixels.length - 1 - row][col];
	    	  topPixel.setColor(bottomPixel.getColor());
	      }
	    }
  }
  
  /** Mirrors just a square part of the picture from bottom left to top right */
  public void mirrorDiagonal() {
	  Pixel[][] pixels = this.getPixels2D();
	  Pixel leftPixel = null;
	  Pixel rightPixel = null;
	  int diagonal = 0;
	  int length = pixels.length;
	  for (int row = 0; row < length; row++) {
		for (int col = 0; col < row + 1; col++) {
			leftPixel = pixels[row][col];
			rightPixel = pixels[col][row];
			rightPixel.setColor(leftPixel.getColor());
		}
	  }
	  
	  //for (int row = 0; row < length; row++) {
			//for (int col = row; col < row + 1; col++) {
	  
  }
   
  
  /** Mirror just part of a picture of a temple */
  public void mirrorTemple()
  {
    int mirrorPoint = 276;
    Pixel leftPixel = null;
    Pixel rightPixel = null;
    int count = 0;
    Pixel[][] pixels = this.getPixels2D();
    
    // loop through the rows
    for (int row = 27; row < 97; row++)
    {
      // loop from 13 to just before the mirror point
      for (int col = 13; col < mirrorPoint; col++)
      {
  
        leftPixel = pixels[row][col];      
        rightPixel = pixels[row]                       
                         [mirrorPoint - col + mirrorPoint];
        rightPixel.setColor(leftPixel.getColor());
        count++;
      }
    }
    System.out.println(count);
  }
  
  /** Method that mirrors the arms of a snowman */
  public void mirrorArms() {
	  Pixel topPixel = null;
	  Pixel bottomPixel = null;
	  Pixel[][] pixels = this.getPixels2D();
	  int mirrorPoint1 = 190;
	  int mirrorPoint2 = 193;
	  // left arm
	 for (int row = 156; row < mirrorPoint1; row++) {
		 for (int col = 100; col < 172; col++) {
			 topPixel = pixels[row][col];
			 bottomPixel = pixels[mirrorPoint1 - row + mirrorPoint1][col];
			 bottomPixel.setColor(topPixel.getColor());
		 }
	 }
	 // right arm
	 for (int row = 170; row < mirrorPoint2; row++) {
		 for (int col = 237; col < 297; col++) {
			 topPixel = pixels[row][col];
			 bottomPixel = pixels[mirrorPoint2 - row + mirrorPoint2][col];
			 bottomPixel.setColor(topPixel.getColor());
		 }
	 }
  }
  
  /** Method to mirror the seagull to the right to make it appear as if two seagulls are next to each other */
  public void mirrorGull() {
	  Pixel leftPixel = null;
	  Pixel rightPixel = null;
	  Pixel[][] pixels = this.getPixels2D();
	  int mirrorPoint = 348;
	  for (int row = 233; row < 321; row++) {
		  for (int col = 236; col < mirrorPoint; col++) {
			  leftPixel = pixels[row][col];
			  rightPixel = pixels[row][mirrorPoint - col + mirrorPoint];
			  rightPixel.setColor(leftPixel.getColor());
		  }
	  }
  }
  
  /** copy from the passed fromPic to the
    * specified startRow and startCol in the
    * current picture
    * @param fromPic the picture to copy from
    * @param startRow the start row to copy to
    * @param startCol the start col to copy to
    */
  public void copy(Picture fromPic, 
                 int startRow, int startCol)
  {
    Pixel fromPixel = null;
    Pixel toPixel = null;
    Pixel[][] toPixels = this.getPixels2D();
    Pixel[][] fromPixels = fromPic.getPixels2D();
    for (int fromRow = 0, toRow = startRow; 
         fromRow < fromPixels.length &&
         toRow < toPixels.length; 
         fromRow++, toRow++)
    {
      for (int fromCol = 0, toCol = startCol; 
           fromCol < fromPixels[0].length &&
           toCol < toPixels[0].length;  
           fromCol++, toCol++)
      {
        fromPixel = fromPixels[fromRow][fromCol];
        toPixel = toPixels[toRow][toCol];
        toPixel.setColor(fromPixel.getColor());
      }
    }   
  }
  
  /** copy only a part from the passed fromPic to
   * the specified startRow and startCol in the currentPicture
   * to the endRow and endCol in the current picture
   * @param fromPic the picture to copy from
   * @param startRow the row to start copying from
   * @param startCol the column to start copying from
   * @param startPic specifies what row of the picture should be copied
   * @param startPicCol specifies what column of the picture should be copied 
   * @param endRow the row to end copying from
   * @param endCol the column to end copying from
   */
  public void copy2(Picture fromPic, int startCopyingRow, int startCopyingCol, int startPic, int startPicCol, int endRow, int endCol) {
	  Pixel fromPixel = null;
	  Pixel toPixel = null;
	  Pixel[][] toPixels = this.getPixels2D();
	  Pixel[][] fromPixels = fromPic.getPixels2D();
	  for (int fromRow = startPic, toRow = startCopyingRow; 
		         fromRow < endRow &&
		         toRow < toPixels.length; 
		         fromRow++, toRow++)
		    {
		      for (int fromCol = startPicCol, toCol = startCopyingCol; 
		           fromCol < endCol &&
		           toCol < toPixels[0].length;  
		           fromCol++, toCol++)
		      {
		        fromPixel = fromPixels[fromRow][fromCol];
		        toPixel = toPixels[toRow][toCol];
		        toPixel.setColor(fromPixel.getColor());
		      }
		    }
  }

  /** Method to create a collage of several pictures */
  public void createCollage()
  {
    Picture flower1 = new Picture("flower1.jpg");
    Picture flower2 = new Picture("flower2.jpg");
    // for copy method #1
    // this.copy(flower1,0,0); 
    // this.copy(flower2,100,0);
    // this.copy(flower1,200,0); 
    
    // for copy method #2
    this.copy2(flower1, 0, 0, 0, 0, 50, 100);
    this.copy2(flower2, 100, 0, 0, 0, 50, 100);
    this.copy2(flower1, 200, 0, 0, 0, 50,  100); 
    
    Picture flowerNoBlue = new Picture(flower2);
    flowerNoBlue.zeroBlue();
    // for copy method #1
    // this.copy(flowerNoBlue,300,0);
    // this.copy(flower1,400,0);
    // this.copy(flower2,500,0); 
    
    // for copy method #2
    Picture robot = new Picture("robot.jpg");
    robot.negate();
    this.copy2(robot, 300, 0, 0, 0, 72, 20);
    this.copy2(flower1, 400, 0, 0, 0, 50, 50);
    this.mirrorVertical();
    this.write("collage.jpg");
  }
  
  /** Method to create a collage of an assortment of pictures */
  public void myCollage() {
	  Picture robot = new Picture("robot.jpg");
	  Picture robot2 = new Picture("robot.jpg");
	  Picture flower = new Picture("flower1.jpg");
	  robot.negate();
	  this.copy(robot, 25, 75);
	  robot2.grayscale();
	  this.copy(robot2, 25, 200);
	  flower.keepOnlyBlue();
	  this.copy(flower, 0, 325);
	  this.mirrorHorizontal();
	  this.write("collage.jpg");
	  
  }
	  
  
  
  
  /** Method to show large changes in color 
    * @param edgeDist the distance for finding edges
    */
  public void edgeDetection(int edgeDist)
  {
    Pixel leftPixel = null;
    Pixel rightPixel = null;
    Pixel topPixel = null;
    Pixel bottomPixel = null;
    Color bottomColor = null;
    Pixel[][] pixels = this.getPixels2D();
    Color rightColor = null;
    for (int row = 0; row < pixels.length - 1; row++)
    {
      for (int col = 0; 
           col < pixels[0].length-1; col++)
      {
        leftPixel = pixels[row][col];
        rightPixel = pixels[row][col+1];
        topPixel = pixels[row][col];
    	bottomPixel = pixels[row + 1][col];
    	bottomColor = bottomPixel.getColor();
        rightColor = rightPixel.getColor();
        if (leftPixel.colorDistance(rightColor) > 
            edgeDist)
          leftPixel.setColor(Color.BLACK);
        else if (topPixel.colorDistance(bottomColor) > edgeDist) 
          topPixel.setColor(Color.BLACK);
        else if (topPixel.colorDistance(bottomColor) < edgeDist) 
          topPixel.setColor(Color.WHITE);
        else
          leftPixel.setColor(Color.WHITE);
      } 
      
    }
    
   
    
  }
  
 /** Another algorithm for edge detection.
  *  Finds the average of the three color values for the pixel and 
  *  tests the difference of it with the average of the next pixel.
  *  If the difference exceeds the value of the given difference (parameter),
  *  the method will detect the pixel as an edge.
  */
  public void edgeDetection2(int difference) {
	  Pixel leftPixel = null;
	  Pixel rightPixel = null;
	  Pixel topPixel = null;
	  Pixel bottomPixel = null;
	  Pixel[][] pixels = this.getPixels2D();
	  Color bottomColor = null;
	  Color rightColor = null;
	  int averageLeft = 0;
	  int averageRight = 0;
	  int averageTop = 0;
	  int averageBottom = 0;
	  for (int row = 0; row < pixels.length - 1; row++) {
		  for (int col = 0; col < pixels[0].length - 1; col++) {
			  leftPixel = pixels[row][col];
			  rightPixel= pixels[row][col + 1];
			  topPixel = pixels[row][col];
			  bottomPixel = pixels[row + 1][col];
			  averageLeft = (leftPixel.getRed() + leftPixel.getGreen() + leftPixel.getBlue()) / 3;
			  averageRight = (rightPixel.getRed() + rightPixel.getGreen() + rightPixel.getBlue()) / 3;
			  averageTop = (topPixel.getRed() + topPixel.getGreen() + topPixel.getBlue()) / 3;
			  averageBottom = (bottomPixel.getRed() + bottomPixel.getGreen() + bottomPixel.getBlue()) / 3;
			  if (Math.abs(averageLeft - averageRight) > difference) 
				  leftPixel.setColor(Color.BLACK);
			  else if (Math.abs(averageTop - averageBottom) > difference) 
				  topPixel.setColor(Color.BLACK);
			  else if (Math.abs(averageTop - averageBottom) < difference)
				  topPixel.setColor(Color.WHITE);
			  else 
				  leftPixel.setColor(Color.WHITE);
			  }
		  }
	  }
  
  /** Method for replacing the current pixel color with
   * the color from another picture at the same row and column
   */
  public void chromakey(Picture comparePic) {
	  Pixel[][] pixels = this.getPixels2D();
	  Pixel[][] otherPicturePixels = comparePic.getPixels2D();
	  Pixel currentPixel = null;
	  Pixel otherPixel = null;
	  for (int row = 0; row < pixels.length; row++) {
		  for (int col = 0; col < pixels[0].length; col++) {
			  currentPixel = pixels[row][col];
			  otherPixel = otherPicturePixels[row][col];
			  if (currentPixel.getRed() < currentPixel.getBlue() && currentPixel.getGreen() < currentPixel.getBlue()) {
				  currentPixel.setColor(otherPixel.getColor());
			  }
		  }
	  }
  }
  
  
  
  /* Main method for testing - each class in Java can have a main 
   * method 
   */
  public static void main(String[] args) 
  {
    Picture beach = new Picture("beach.jpg");
    beach.explore();
    beach.zeroBlue();
    beach.explore();
  }
  
} // this } is the end of class Picture, put all new methods before this
